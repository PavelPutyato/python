number = int(input('Введите любое однозначное число n: '))
number1 = number * 11
number2 = number * 111
number_sum = number + number1 + number2
print('Введеное вами число n:', number)
print(f'Сумма чисел: {number}+{number1}+{number2}={number_sum}')

