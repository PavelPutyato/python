my_list = ['hi', 57, 35.94, True, [1, 5, 8], {4, 'hello', None, 56.9},
           ('8', 'mail', '5'), {'key1': 'tex1', 2: 3, 3: 'mama'}, None, b'text', ]
for el in my_list:
    print(type(el))
